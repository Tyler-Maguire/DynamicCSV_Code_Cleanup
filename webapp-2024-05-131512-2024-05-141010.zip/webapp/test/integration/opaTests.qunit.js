/* global QUnit */

sap.ui.require(["com/epiuse/dynamcsv/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
